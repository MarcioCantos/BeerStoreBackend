package com.vd0.beerstore.test;

import org.junit.Test;

public class ClienteTest {

	@Test
	public void SalvarCliente() {
		
	}
	
}
