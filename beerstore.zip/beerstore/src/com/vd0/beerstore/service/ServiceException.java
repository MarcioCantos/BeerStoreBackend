package com.vd0.beerstore.service;

public class ServiceException extends Exception {
	
	private static final long serialVersionUID = 1;
	
	public ServiceException(String message) {
		super(message);
	}
			

}
